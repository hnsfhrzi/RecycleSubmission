package com.example.recyclesubmission

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        val imgsplash:ImageView = findViewById(R.id.img_splash)
        imgsplash.alpha = 0f
        imgsplash.animate().setDuration(2000L).alpha(1f).withEndAction{
            val mainMovedIntent = Intent(this, MainActivity::class.java)
            startActivity(mainMovedIntent)
            overridePendingTransition(androidx.appcompat.R.anim.abc_fade_in, androidx.appcompat.R.anim.abc_fade_out)
            finish()
        }
    }
}